import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Play, Users, Gamepad2, Trophy, Hash } from "lucide-react";

interface TutorialStep {
  id: number;
  title: string;
  content: string;
  visual?: React.ReactNode;
  tip?: string;
}

const tutorialSteps: TutorialStep[] = [
  {
    id: 1,
    title: "Welcome to ForeScore!",
    content: "ForeScore adds fun competition to your golf rounds with two exciting game options! Play the Card penalty game for laughs when shots go wrong, or try the 2/9/16 points system for stroke-based competition. Both games make every hole more engaging!",
    visual: (
      <div className="text-center p-6 bg-emerald-50 rounded-lg">
        <div className="text-6xl mb-4">⛳</div>
        <h3 className="text-xl font-bold text-emerald-700">ForeScore</h3>
        <p className="text-emerald-600">Two Golf Competition Games</p>
      </div>
    ),
  },
  {
    id: 2,
    title: "Create Your Game and Group",
    content: "Begin by creating a new game, which will prompt you to either create a new group or import an existing one. Each player gets a unique color for easy identification throughout all games.",
    visual: (
      <div className="space-y-3">
        <div className="flex items-center gap-3 p-3 bg-white rounded-lg border">
          <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">J</div>
          <span className="font-medium">John</span>
        </div>
        <div className="flex items-center gap-3 p-3 bg-white rounded-lg border">
          <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-bold">S</div>
          <span className="font-medium">Sarah</span>
        </div>
        <div className="flex items-center gap-3 p-3 bg-white rounded-lg border">
          <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center text-white text-xs font-bold">M</div>
          <span className="font-medium">Mike</span>
        </div>
      </div>
    ),
    tip: "You can create multiple games per group and run both Card and 2/9/16 games simultaneously!"
  },
  {
    id: 3,
    title: "Understanding Penalty Cards",
    content: "There are 7 built-in penalty cards, each representing common golf mishaps. You can also create custom cards with your own names, emojis, and values - they'll appear as editable fields in the Card Values section.",
    visual: (
      <div className="grid grid-cols-2 gap-2">
        <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200 justify-center py-2">
          🐪 Camel - $2
        </Badge>
        <Badge className="bg-blue-100 text-blue-800 border-blue-200 justify-center py-2">
          🐟 Fish - $2
        </Badge>
        <Badge className="bg-orange-100 text-orange-800 border-orange-200 justify-center py-2">
          🐦 Roadrunner - $2
        </Badge>
        <Badge className="bg-purple-100 text-purple-800 border-purple-200 justify-center py-2">
          👻 Ghost - $2
        </Badge>
        <Badge className="bg-gray-100 text-gray-800 border-gray-200 justify-center py-2">
          🦨 Skunk - $2
        </Badge>
        <Badge className="bg-green-100 text-green-800 border-green-200 justify-center py-2">
          🐍 Snake - $2
        </Badge>
      </div>
    ),
    tip: "Camel = sand trap, Fish = water, Roadrunner = cart path, Ghost = out of bounds, Skunk = double bogey, Snake = three putt"
  },
  {
    id: 4,
    title: "Playing the Card Game",
    content: "During your golf round, when someone gets a penalty, go to the Deck tab and assign them the appropriate card. Cards can be reassigned between players throughout the round - strategy is key!",
    visual: (
      <div className="space-y-4">
        <div className="text-center p-4 bg-emerald-50 rounded-lg">
          <Trophy className="h-8 w-8 text-emerald-600 mx-auto mb-2" />
          <p className="font-medium text-emerald-700">Select a card type</p>
          <p className="text-sm text-emerald-600">Choose which penalty occurred</p>
        </div>
        <div className="text-center p-4 bg-blue-50 rounded-lg">
          <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
          <p className="font-medium text-blue-700">Assign to player</p>
          <p className="text-sm text-blue-600">Tap the player who gets the card</p>
        </div>
      </div>
    ),
    tip: "Cards can be traded between players! Use strategy to minimize your final total."
  },
  {
    id: 5,
    title: "Tracking Scores",
    content: "The Payouts tab shows each player's card totals and money paid/received. Use 'Who Owes Who' to see direct payments between players, and check Card History to see all card assignments throughout the round.",
    visual: (
      <div className="space-y-3">
        <div className="p-3 bg-gray-50 rounded-lg border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">J</div>
              <span className="font-medium">John</span>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-green-600">$3.00</p>
              <p className="text-xs text-gray-600">Receives</p>
            </div>
          </div>
        </div>
        <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
          <div className="text-sm">
            <span className="font-medium text-red-600">Sarah</span>
            <span className="text-gray-600"> owes </span>
            <span className="font-medium text-green-600">John</span>
            <span className="ml-2 font-bold text-black">$3.00</span>
          </div>
        </div>
      </div>
    ),
    tip: "Check the Payouts tab to see all money calculations and card assignments!"
  },
  {
    id: 6,
    title: "Multiplayer Support",
    content: "Share your game code with other players so they can join from their own devices. Everyone can assign cards and see real-time updates throughout the round.",
    visual: (
      <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg border">
        <div className="text-3xl mb-3">📱➡️📱</div>
        <div className="bg-white px-4 py-2 rounded-lg border-2 border-dashed border-blue-300 mb-3">
          <span className="font-mono text-lg font-bold text-blue-600">ABC123</span>
        </div>
        <p className="text-sm text-gray-600">Share this code with other players</p>
      </div>
    ),
    tip: "Each game gets its own unique share code for easy joining!"
  },
  {
    id: 7,
    title: "2/9/16 Game with Dual Payouts",
    content: "ForeScore includes a stroke-based competition with two payout systems! Toggle between 'Points' (pay based on point differences) and 'FBT' (winners for Front 9, Back 9, and Total). Both systems run simultaneously so you can choose your preferred payout method!",
    visual: (
      <div className="space-y-4">
        <div className="text-center p-4 bg-blue-50 rounded-lg border border-blue-200">
          <Hash className="h-8 w-8 text-blue-600 mx-auto mb-2" />
          <p className="font-medium text-blue-700">2/9/16 Points Game</p>
          <p className="text-sm text-blue-600">Dual payout systems</p>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-blue-100 p-2 rounded text-center border border-blue-200">
            <div className="font-bold text-blue-700">Points</div>
            <div className="text-blue-600">Point differences</div>
          </div>
          <div className="bg-green-100 p-2 rounded text-center border border-green-200">
            <div className="font-bold text-green-700">FBT</div>
            <div className="text-green-600">Front/Back/Total winners</div>
          </div>
        </div>
      </div>
    ),
    tip: "Check the Payouts tab to see both payout systems side by side!"
  },
  {
    id: 8,
    title: "Ready to Enhance Your Golf Round!",
    content: "You're all set! Create your first group and add excitement to your golf round with ForeScore's two game options. Whether you want penalty-based laughs or stroke competition, these games will make every hole more engaging!",
    visual: (
      <div className="text-center p-6 bg-gradient-to-br from-emerald-50 to-green-50 rounded-lg">
        <Trophy className="h-12 w-12 text-emerald-600 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-emerald-700 mb-2">Enjoy Your Round!</h3>
        <p className="text-emerald-600">Make every hole more fun</p>
        <div className="flex justify-center gap-4 mt-4">
          <div className="text-2xl">🐪</div>
          <div className="text-2xl">🐟</div>
          <div className="text-2xl">#</div>
        </div>
      </div>
    ),
    tip: "Pro tip: Card penalty game and 2/9/16 can run simultaneously to add multiple layers of competition to your round!"
  }
];

export function Tutorial() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isStarted, setIsStarted] = useState(false);

  const currentTutorialStep = tutorialSteps[currentStep];
  const isLastStep = currentStep === tutorialSteps.length - 1;
  const isFirstStep = currentStep === 0;

  if (!isStarted) {
    return (
      <div className="p-4">
        <Card>
          <CardContent className="p-8 text-center">
            <div className="mb-6">
              <div className="text-6xl mb-4">🎓</div>
              <h2 className="text-2xl font-bold text-gray-800 mb-2">Learn ForeScore</h2>
              <p className="text-gray-600">
                New to ForeScore? Learn how to add exciting competition to your golf rounds with two fun game options!
              </p>
            </div>
            
            <div className="space-y-4">
              <Button 
                onClick={() => setIsStarted(true)}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-3 text-lg"
              >
                <Play className="mr-2 h-5 w-5" />
                Start Tutorial
              </Button>
              
              <div className="text-sm text-gray-500">
                Takes about 3 minutes • {tutorialSteps.length} steps
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4">
      <Card>
        <CardContent className="p-6">
          {/* Progress indicator */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">
                Step {currentStep + 1} of {tutorialSteps.length}
              </span>
              <span className="text-sm text-gray-500">
                {Math.round(((currentStep + 1) / tutorialSteps.length) * 100)}% complete
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-emerald-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${((currentStep + 1) / tutorialSteps.length) * 100}%` }}
              />
            </div>
          </div>

          {/* Tutorial content */}
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-gray-800 mb-3">
                {currentTutorialStep.title}
              </h2>
              <p className="text-gray-600 leading-relaxed">
                {currentTutorialStep.content}
              </p>
            </div>

            {/* Visual component */}
            {currentTutorialStep.visual && (
              <div className="my-6">
                {currentTutorialStep.visual}
              </div>
            )}

            {/* Tip */}
            {currentTutorialStep.tip && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-2">
                  <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-white text-xs font-bold">💡</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-blue-800 mb-1">Pro Tip</h4>
                    <p className="text-sm text-blue-700">{currentTutorialStep.tip}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Navigation */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            {/* Navigation dots */}
            <div className="flex items-center justify-center gap-2 mb-4">
              {tutorialSteps.map((_, index) => (
                <div
                  key={index}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index <= currentStep ? 'bg-emerald-500' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>

            {/* Navigation buttons */}
            <div className="flex items-center justify-between">
              <Button
                onClick={() => setCurrentStep(currentStep - 1)}
                variant="outline"
                disabled={isFirstStep}
                className="flex items-center gap-2"
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>

              {isLastStep ? (
                <Button
                  onClick={() => {
                    setIsStarted(false);
                    setCurrentStep(0);
                  }}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white"
                >
                  Finish Tutorial
                </Button>
              ) : (
                <Button
                  onClick={() => setCurrentStep(currentStep + 1)}
                className="bg-emerald-500 hover:bg-emerald-600 text-white flex items-center gap-2"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}